//
//  DetailViewController.swift
//  ETBD Directory
//
//  Created by Max Porrino on 3/10/21.
//

import UIKit

class DetailViewController: UIViewController {
    @IBOutlet weak var professorName: UILabel!
    @IBOutlet weak var professorImage: UIImageView!
    @IBOutlet weak var professorClasses: UILabel!
    @IBOutlet weak var professorOffice: UILabel!
    
    var selectedProfessorName = "Artie"
    var selectedProfessorClasses = "IMS 351"
    var selectedProfessorOffice = "Laws Hall"
    var selectedProfessorEmail = ""
    var selectedProfessorOfficeLink = ""
    
    @IBAction func sendEmailButton(_ sender: Any) {
        if let url = URL(string: selectedProfessorEmail) {
                    UIApplication.shared.open(url)
                }
    }
   
    @IBAction func goToOfficeHoursButton(_ sender: Any) {
        if let url = URL(string: selectedProfessorOfficeLink) {
                    UIApplication.shared.open(url)
                }
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        professorName.text = selectedProfessorName
        professorClasses.text = selectedProfessorClasses
        professorOffice.text = selectedProfessorOffice
        professorImage.image = UIImage(named: selectedProfessorName + ".img")
        // prints above variables, had to put string in front selectedComicIssueNumber in order for it to show up
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
