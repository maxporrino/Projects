//
//  ViewController.swift
//  ETBD Directory
//
//  Created by Max Porrino on 3/10/21.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBAction func sortName(_ sender: Any) {
        Professors.sort { $0.name < $1.name }
        professorTable.reloadData()
    }
    
    // works with Array/Professor List
    struct Professor {
        let name: String
        let classes: String
        let office: String
        let email: String
        let officeLink: String
    }
    
    // Professor List
     var Professors = [Professor(name: "Artie Kuhn", classes: "Classes: IMS 322, 351, 354", office: "Office: Laws Hall, 305E", email: "mailto:kuhnar@miamioh.edu", officeLink: "https://calendar.google.com/calendar/u/0/selfsched?sstoken=UUloejMyUXRnNzl4fGRlZmF1bHR8YjI5ODM5ZTJiMTRlNzc2Y2U2YjMyMWQ2ODNmMjhlN2Q"), Professor(name: "Glenn Platt", classes: "Classes: IMS 418", office: "Office: Laws Hall, 209F" , email: "mailto:plattgj@miamioh.edu", officeLink: "https://www.miamioh.edu/cca/academics/departments/etbd/about/our-people/faculty/aims-office-hours/index.html"),Professor(name: "Phill Alexander", classes: "Classes: IMS 102, 317, 470, 471", office: "Office: Laws Hall, 203", email: "mailto:phill.alexander@miamioh.edu", officeLink: "https://calendar.google.com/calendar/u/0/selfsched?sstoken=UUlzSHhIZWxhbFltfGRlZmF1bHR8MDc5NjM3ZmNkMTMzMjMzNjdiYzEwMDA3YzNhMjk4YWI"), Professor(name: "Erin Brandyberry", classes: "Classes: IMS 278", office: "Office: Laws Hall, 209", email: "mailto:erin.brandyberry@miamioh.edu", officeLink: "https://calendar.google.com/calendar/u/0/selfsched?sstoken=UUlkdEVsWHFIVzkxfGRlZmF1bHR8NzczMzUxMGEzYWZmNDI1MzM0MThhODIwODUwMzIyMmM"), Professor(name: "Michael Bailey-Van Kuren", classes: "Classes: IMS 228, 540", office: "Office: Laws Hall, 210A", email: "mailto:baileym@MiamiOH.edu", officeLink: "https://calendar.google.com/calendar/u/0/selfsched?sstoken=UU1fVDBPSDEzelNifGRlZmF1bHR8ZTVmODI2Mzk4YTQ4NzhhMzlmNGUzMzZjMTE3ODNkZjI"), Professor(name: "Bob Black", classes: "Classes: IMS 440, 540", office: "Office: N/A", email: "mailto:blackrw@miamioh.edu", officeLink: "https://calendar.google.com/calendar/u/0/selfsched?sstoken=UUtIdHJERm1XM0g3fGRlZmF1bHR8MzVmM2M4Nzg4MTZhNzI2MTI1ODk4MDFjMzdiNDNjNzQ"), Professor(name: "Matthew Board", classes: "Classes: IMS 218, 445, 487", office: "Office: Hiestand Hall, 222/King 027", email: "mailto:boardmj@MiamiOH.edu", officeLink: "https://www.miamioh.edu/cca/academics/departments/etbd/about/our-people/faculty/aims-office-hours/index.html"), Professor(name: "Vanessa Cannon", classes: "Classes: IMS 254, 354", office: "Office: Online By Appointment", email: "mailto:cannonva@miamioh.edu", officeLink: "https://calendar.google.com/calendar/u/0/selfsched?sstoken=UUFMSUd6NUhzWGhFfGRlZmF1bHR8ZjAzYjRlMDMxNzAwNDFlMDNlZjljMjNhOTk5M2RhMDM"), Professor(name: "James Coyle", classes: "Classes: IMS 228, 413, 513", office: "Office: Farmer School of Business, 2045B", email: "mailto:coylejr@MiamiOH.edu", officeLink: "https://calendar.google.com/calendar/u/0/selfsched?sstoken=UUExWTlOa0JiS1pIfGRlZmF1bHR8ZGMxNzg1ZGU3MzI3ZDJiZGI4ZDQ2Y2IyMTUwY2NhYjQ"), Professor(name: "Bob De Schutter", classes: "Classes: IMS 453, 489", office: "Office: McGuffey Hall, 214A", email: "mailto:bobdeschutter@MiamiOH.edu", officeLink: "https://calendar.google.com/calendar/u/0/selfsched?sstoken=UUpXTy1SdXNrZEtpfGRlZmF1bHR8NGMzZWNhMDA3Njc2NGE3NzJlZTJjY2MyMDM3ZGQ5ZGQ"), Professor(name: "Tim DeMarks", classes: "Classes: IMS 211, 212, 452", office: "Office: Laws Hall, 203", email: "mailto:demarktg@miamioh.edu", officeLink: "https://calendar.google.com/calendar/u/0/selfsched?sstoken=UUVEbHdKVmt6Tm1kfGRlZmF1bHR8ZjE4YjBkYmJhMWM2YWM4ZTNjYTk4NWNmMmE5ZGY3OWE"), Professor(name: "Sarah Frick", classes: "Classes: IMS 254, 259 (None This Spring)", office: "Office: Laws Hall, 203", email: "mailto:fricksc@miamioh.edu", officeLink: "https://calendar.google.com/calendar/u/0/selfsched?sstoken=UUpWRG1faF9pWGJZfGRlZmF1bHR8ZjAwYmRjM2NhMzk3ZmJlMDc0ZDU3MmVkOGI2YTJhMTI"), Professor(name: "Rachel Hellgren", classes: "Classes: IMS 254, 452", office: "Office: Laws Hall, 213", email: "mailto:hellgrrk@miamioh.edu", officeLink: "https://calendar.google.com/calendar/u/0/selfsched?sstoken=UURyTTU2VlRXNlBSfGRlZmF1bHR8ZGNiNTNmZGFkNzRmNWJlZWVmZjExY2JmNzU2OGNjMzk"), Professor(name: "Ray Heyob", classes: "Classes: IMS 222, 421", office: "Office: Laws Hall, 203", email: "mailto:heyobrr@miamioh.edu", officeLink: "https://www.miamioh.edu/cca/academics/departments/etbd/about/our-people/faculty/aims-office-hours/index.html"), Professor(name: "Eric Hodgson", classes: "Classes: IMS 319", office: "Office: Laws Hall, 305D", email: "mailto:eric.hodgson@MiamiOH.edu", officeLink: "https://calendar.google.com/calendar/u/0/selfsched?sstoken=UUJpa3VyQ01hUWVZfGRlZmF1bHR8NDg0Y2MyY2Q0ODlkN2YzOTNmZmNlYzYxMjIzNDk1NWU"), Professor(name: "Kirk Hopkins", classes: "Classes: IMS 222", office: "Office: Laws Hall, 213D", email: "mailto:hopkinks@miamioh.edu", officeLink: "https://miamioh.edu/cca/academics/departments/etbd/about/our-people/faculty/aims-office-hours/index.html"), Professor(name: "Paul Hunter", classes: "Classes: IMS 414, 419, 514, 519", office: "Office: Laws Hall, 209", email: "mailto:hunterpe@miamioh.edu", officeLink: "https://miamioh.edu/cca/academics/departments/etbd/about/our-people/faculty/aims-office-hours/index.html"), Professor(name: "Shelli Minton", classes: "Classes: IMS 222", office: "Office: Nellie Craig Walker Hall, Room 22", email: "mailto:mintondm@miamioh.edu", officeLink: "https://miamioh.edu/cca/academics/departments/etbd/about/our-people/faculty/aims-office-hours/index.html"), Professor(name: "Molly Moran", classes: "Classes: IMS 228, 259, 278", office: "Office: Laws Hall, 210", email: "mailto:molly.moran@miamioh.edu", officeLink: "https://calendar.google.com/calendar/u/0/selfsched?sstoken=UUhzWTliMjV5Ti1yfGRlZmF1bHR8YThlZDkwNWYwYWUwNWY5NGRiODg3NmI5MjRjNTU4OWU"), Professor(name: "Bruce Murray", classes: "Classes: IMS 322, 381", office: "Office: Laws 209B", email: "mailto:murraybj@MiamiOH.edu", officeLink: "https://calendar.google.com/calendar/u/0/selfsched?sstoken=UUFIeEZoUXRHRXFOfGRlZmF1bHR8Nzg0Yjc3YWViODUzYzg5OTBjMDI4OTJlMjc3NmY5YzY"), Professor(name: "Ben Nicholson", classes: "Classes: IMS 430, 431, 440, 530, 531", office: "Office: Laws Hall, 209", email: "mailto:nicholb8@miamioh.edu", officeLink: "https://calendar.google.com/calendar/u/0/selfsched?sstoken=UUtVa3V2VVVQeGRlfGRlZmF1bHR8M2ViZDVjMDBjYmM3ZmQwM2ExOTQxNzM0NTYzZGZlMWM"), Professor(name: "Taylor O'Neal", classes: "Classes: IMS 414", office: "Office: Laws Hall, 203", email: "mailto:onealtb@miamioh.edu", officeLink: "https://miamioh.edu/cca/academics/departments/etbd/about/our-people/faculty/aims-office-hours/index.html"), Professor(name: "Murali Paranandi", classes: "Classes: IMS 404", office: "Office: 106-A, Alumni Hall", email: "mailto:murali.paranandi@MiamiOH.edu", officeLink: "https://miamioh.edu/cca/academics/departments/etbd/about/our-people/faculty/aims-office-hours/index.html"), Professor(name: "Jim Porter", classes: "Classes: IMS 171, 424, 524", office: "Office: Bachelor Hall, 279", email: "mailto:porterje@MiamiOH.edu", officeLink: "https://miamioh.edu/cca/academics/departments/etbd/about/our-people/faculty/aims-office-hours/index.html"), Professor(name: "Adam Strantz", classes: "Classes: IMS 222, 322", office: "Office: Bachelor Hall, 278", email: "mailto:strantaw@miamioh.edu", officeLink: "https://calendar.google.com/calendar/u/0/selfsched?sstoken=UUtsaWhTM1dyWFBxfGRlZmF1bHR8ZTQyNjhmOTJmNDU2OTFkODAxNjhlYWMzMzdkMjcxMDc"), Professor(name: "Elijah Van Benschoten", classes: "Classes: IMS 259", office: "Office: Laws Hall, 203", email: "mailto:vanbene@miamioh.edu", officeLink: "https://miamioh.edu/cca/academics/departments/etbd/about/our-people/faculty/aims-office-hours/index.html"), Professor(name: "Jerry Yarnetsky", classes: "Classes: IMS 222", office: "Office: King Library, 302", email: "mailto:yarnete@miamioh.edu", officeLink: "https://muohio.libcal.com/appointments/jerry-yarnetsky")]
    var display: [Professor] = []
   
    // Number of Rows, always has to return a number for number of rows where it says code or variable that holds array
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Professors.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = professorTable.dequeueReusableCell(withIdentifier: "professorCell")
                
        cell?.textLabel?.text = Professors[indexPath.row].name // prints stuff in Array onto table
                
                return cell!
    }
    

    @IBOutlet weak var professorTable: UITableView!
    
    // Makes Segue connect along with populating the data on each screen
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            
        // connects new view controller
            if segue.identifier == "goToDetailViewController" {
                let destination = segue.destination as? DetailViewController
                
                destination?.selectedProfessorName = Professors[professorTable.indexPathForSelectedRow!.row].name
                destination?.selectedProfessorClasses = Professors[professorTable.indexPathForSelectedRow!.row].classes
                destination?.selectedProfessorOffice = Professors[professorTable.indexPathForSelectedRow!.row].office
                destination?.selectedProfessorEmail = Professors[professorTable.indexPathForSelectedRow!.row].email
                destination?.selectedProfessorOfficeLink = Professors[professorTable.indexPathForSelectedRow!.row].officeLink
                
            }
        }
    
    override func viewWillAppear(_ animated: Bool) {
        if let indexPath = professorTable.indexPathForSelectedRow {
            professorTable.deselectRow(at: indexPath, animated: true)
        }
    }
   
    override func viewDidLoad() {
        super.viewDidLoad()
        professorTable.dataSource = self
        professorTable.delegate = self
        // Do any additional setup after loading the view.
        
        // Always copy and paste this under here for delegate
        
        // Do any additional setup after loading the view.
    }


}

